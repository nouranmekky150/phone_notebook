insert into notebook.table2 values ('aasdasd' , 'cairo' , '014555');
insert into notebook.table2 values ('aasd' , 'menofia' , '0145554');
insert into notebook.table2 values ('aasd' , 'cairo' , '0145554455');
